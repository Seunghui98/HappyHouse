package com.ssafy.happyhouse.model.mapper;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;


import com.ssafy.happyhouse.model.BoardDto;

@Mapper
public interface BoardMapMapper {
	int getTotalCount(Map<String, String> map) throws Exception;
	int regist(BoardDto boardDto) throws SQLException;
	int delete(int num) throws SQLException;
	List<BoardDto> listBoard(Map<String, Object> map) throws Exception;
	BoardDto getBoard(int num) throws Exception;
	void update(BoardDto boardDto) throws Exception;
	
}
