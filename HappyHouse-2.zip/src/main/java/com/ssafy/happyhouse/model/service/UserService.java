package com.ssafy.happyhouse.model.service;

import java.util.Map;

import com.ssafy.happyhouse.model.UserDto;


public interface UserService {
	int idCheck(String id);
	void registerUser(UserDto user) throws Exception;
	UserDto login(Map<String, String> map) throws Exception;
	UserDto getUser(String id) throws Exception;
	void updateUser(UserDto user) throws Exception;
	void deleteUser(String id) throws Exception;
}
