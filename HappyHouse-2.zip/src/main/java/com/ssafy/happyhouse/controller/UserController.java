package com.ssafy.happyhouse.controller;

import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.happyhouse.model.UserDto;
import com.ssafy.happyhouse.model.service.UserService;

@Controller
@RequestMapping("/user")
@CrossOrigin("*")
public class UserController {
	
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	private UserService userService;
	
	@GetMapping("/regist")
	public String register() {
		return "signup";
	}
	
	@PostMapping("/regist")
	public ModelAndView register(UserDto userDto) {
		ModelAndView mav = new ModelAndView();
		try {
			userService.registerUser(userDto);
			mav.addObject("msg", "회원가입을 성공했습니다.");
			mav.setViewName("login");
			return mav;
		} catch (Exception e) {
			e.printStackTrace();
			mav.addObject("msg", "회원가입 중 에러가 발생했습니다.");
			mav.setViewName("error/error");
			return mav;
		}
	}
	
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
	
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	@PostMapping("/login")
	public String login(@RequestParam Map<String, String> map, Model model, HttpSession session, HttpServletResponse response) throws Exception {
		logger.debug("map : {} {}", map.get("id"), map.get("password"));
		UserDto userDto = userService.login(map);
	
		if(userDto != null) {
			session.setAttribute("userInfo", userDto);
			Cookie cookie = new Cookie("id", map.get("id"));
			cookie.setPath("/");
			if ("saveok".equals(map.get("idsave"))) {
				cookie.setMaxAge(60 * 60 * 24 * 365 * 40);
			} else {
				cookie.setMaxAge(0);
			}
			response.addCookie(cookie);
			return "redirect:/";
		} else {
			model.addAttribute("msg", "아이디 또는 비밀번호 확인 후 다시 로그인 하세요!");
			return "login";
		}
	}
	
	@PostMapping("/update")
	public ModelAndView update(UserDto userDto) throws Exception {
		logger.debug("map : {}", userDto.getId());
		ModelAndView mav = new ModelAndView();
		userService.updateUser(userDto);
		mav.addObject("userInfo", userDto);
		mav.setViewName("mypage");
		return mav;
	}
	
	@GetMapping("/update")
	public String update() {
		return "update";
	}
	
	@GetMapping("/mypage")
	public String searchUser() {
		return "mypage";
	}
	
	@GetMapping("/delete")
	public String deleteUser(@RequestParam(value = "id") String id, HttpSession session) {
		try {
			userService.deleteUser(id);
			session.invalidate();
			return "index";
		} catch (Exception e) {
			e.printStackTrace();
			return "error/error";
		}
	}
	
	
	
	
	
	
}
