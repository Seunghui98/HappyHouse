package com.ssafy.happyhouse.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ssafy.happyhouse.model.BoardDto;
import com.ssafy.happyhouse.model.UserDto;
import com.ssafy.happyhouse.model.service.BoardService;
import com.ssafy.util.PageNavigation;

@Controller
@RequestMapping("/board")
public class BoardController {
	
	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	
	@Autowired
	private BoardService boardService;
	
	
	
	@GetMapping("/regist")
	public String regist() {
		return "write";
	}
	
	@GetMapping("/{num}")
	public ModelAndView get_post(@PathVariable int num) throws Exception{
		ModelAndView mav = new ModelAndView();
		BoardDto boardDto = boardService.getBoard(num);
		boardDto.setNum(num);
		mav.addObject("board", boardDto);
		mav.setViewName("post");
		return mav;
	}
	
	
	
	
	@PostMapping("/regist")
	public String regist(BoardDto boardDto, Model model, HttpSession session, RedirectAttributes redirectAttributes) throws Exception{
		UserDto userDto = (UserDto) session.getAttribute("userInfo");
		boardDto.setId(userDto.getId());
		boardService.register(boardDto);
		redirectAttributes.addAttribute("pg", 1);
		redirectAttributes.addAttribute("key", "");
		redirectAttributes.addAttribute("word", "");
		redirectAttributes.addFlashAttribute("msg", "글작성 성공!!!");
		return "redirect:/board/list";
		
	}
	
	@GetMapping("/list")
	public ModelAndView list(@RequestParam Map<String, String> map) throws Exception {
		ModelAndView mav = new ModelAndView();
		String spp = map.get("spp"); // size per page : 페이지당 글 갯수
		String pg = map.get("pg");
		System.out.println(pg);
		map.put("pg", pg != null ? pg : "0");
		map.put("spp", spp != null ? spp : "10");
		
		List<BoardDto> list = boardService.listBoard(map);
		PageNavigation pageNavigation = boardService.makePageNavigation(map);
		mav.addObject("boards", list);
		mav.addObject("navigation", pageNavigation);
		mav.addObject("key", map.get("key"));
		mav.addObject("word", map.get("word"));
		mav.setViewName("notice");
		return mav;
	}
	@GetMapping("/update/{num}")
	public ModelAndView update(@PathVariable int num) throws Exception {
		ModelAndView mav = new ModelAndView();
		BoardDto boardDto = boardService.getBoard(num);
		mav.addObject("board", boardDto);
		mav.setViewName("notice_update");
		return mav;
	}

	
	@PostMapping("/update")
	public String update(BoardDto boardDto, Model model, HttpSession session, RedirectAttributes redirectAttributes) throws Exception {
		UserDto userDto = (UserDto) session.getAttribute("userInfo");
		boardDto.setId(userDto.getId());
		boardService.updateBoard(boardDto);
		redirectAttributes.addAttribute("pg", 1);
		redirectAttributes.addAttribute("key", "");
		redirectAttributes.addAttribute("word", "");
		redirectAttributes.addFlashAttribute("msg", "글 수정 성공!!!");
		return "redirect:/board/"+boardDto.getNum();
	}
	

	
	@GetMapping("/delete")
	public String delete(@RequestParam("num") int num, Model model, RedirectAttributes redirectAttributes) throws Exception{
		boardService.deleteBoard(num);
		redirectAttributes.addAttribute("pg", 1);
		redirectAttributes.addAttribute("key", "");
		redirectAttributes.addAttribute("word", "");
		redirectAttributes.addFlashAttribute("msg", "글 삭제 성공!!!");
		return "redirect:/board/list";
	}
	
}
